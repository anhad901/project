using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace A2AnhadSinghP1
{
	class Program
	{
		static void volume(double a)
		{
			double x = 4 / 3 * 3.14 * a*a*a;
			Console.WriteLine("volume of sphere=" + x);
		}
		static void volume(double rd, double h)
		{
			double y = 3.14 * rd * rd *h;
			Console.WriteLine("volume of cylinder=" + y);
		}
		static void volume(double lgt, double wd,double hght)
		{
			double z =lgt*wd*hght;
			Console.WriteLine("volume of rectangular prism =+z");
		}
		static void Main(string[] args)
		{
			Console.WriteLine("ENTER YOUR CHOICE:");
			Console.WriteLine("1.Volume of Sphere");
			Console.WriteLine("2.Volume of Cylinder");
			Console.WriteLine("3.Volume of Rectangular prism");
		string et=Console.ReadLine();
			int ch = int.Parse(et);

			switch (et)
			{
				case 1:
					Console.WriteLine("volume of sphere");
                    Console.WriteLine("Enter Radius: ");
                    string sp = Console.ReadLine();
                    double sr = double.Parse(sp);
                    volume(sr);
					break;
				case 2:
					Console.WriteLine("Volume of Cylinder");
                    Console.WriteLine("enter radius of cylinder: ");
                    Console.WriteLine("enter height of cylinder: ");
                    string p = Console.ReadLine();
                    string q = Console.ReadLine();
                    double ab= double.Parse(p);
                    double bc=double.Parse(q);
                    volume(ab+bc);
					break;
				case 3:
					Console.WriteLine("volume of rectangular prism");
                    Console.WriteLine("enter lenght of prism : ");
                    Console.WriteLine("enter width of prism : ");
                    Console.WriteLine("enter height of prim : ");
                    string l = Console.ReadLine();
                    string w = Console.ReadLine();
                    string H = Console.ReadLine();
                    double length = double.Parse(l);
                    double width = double.Parse(w);
                    double height = double.Parse(H);
                    volume(length,width,height);
					break;
				default:
					Console.WriteLine("Invalid Selection");
					break;
			}

		}
	}
}
